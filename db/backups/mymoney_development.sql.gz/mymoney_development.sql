-- MySQL dump 10.13  Distrib 5.6.22, for osx10.10 (x86_64)
--
-- Host: localhost    Database: mymoney_development
-- ------------------------------------------------------
-- Server version	5.6.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `budgets`
--

DROP TABLE IF EXISTS `budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `budgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `budget_month` date NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `by_category_month` (`category_id`,`budget_month`),
  KEY `index_budgets_on_category_id` (`category_id`),
  CONSTRAINT `fk_rails_a52bce3297` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budgets`
--

LOCK TABLES `budgets` WRITE;
/*!40000 ALTER TABLE `budgets` DISABLE KEYS */;
INSERT INTO `budgets` VALUES (1,1,'2015-06-01',508.47,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(2,2,'2015-06-01',120.96,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(3,3,'2015-06-01',21.33,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(4,4,'2015-06-01',271.92,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(5,5,'2015-06-01',87.80,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(6,1,'2015-07-01',489.44,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(7,2,'2015-07-01',103.14,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(8,3,'2015-07-01',168.02,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(9,4,'2015-07-01',272.79,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(10,5,'2015-07-01',191.83,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(11,1,'2015-08-01',391.66,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(12,2,'2015-08-01',153.62,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(13,3,'2015-08-01',184.22,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(14,4,'2015-08-01',262.43,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(15,5,'2015-08-01',150.10,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(16,1,'2015-09-01',339.62,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(17,2,'2015-09-01',136.04,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(18,3,'2015-09-01',193.34,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(19,4,'2015-09-01',277.60,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(20,5,'2015-09-01',152.07,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(21,6,'2015-06-01',0.00,'2015-09-26 02:31:05','2015-09-26 02:31:05'),(22,6,'2015-07-01',0.00,'2015-09-26 02:31:05','2015-09-26 02:31:05'),(23,6,'2015-08-01',0.00,'2015-09-26 02:31:05','2015-09-26 02:31:05'),(24,6,'2015-09-01',850.00,'2015-09-26 02:31:05','2015-09-26 02:31:39'),(144,1,'2015-10-01',298.97,'2015-10-21 16:39:41','2015-10-21 16:39:41'),(145,2,'2015-10-01',162.68,'2015-10-21 16:39:41','2015-10-21 16:39:41'),(146,3,'2015-10-01',166.95,'2015-10-21 16:39:41','2015-10-21 16:39:41'),(147,4,'2015-10-01',283.90,'2015-10-21 16:39:41','2015-10-21 16:39:41'),(148,5,'2015-10-01',130.32,'2015-10-21 16:39:41','2015-10-21 16:39:41'),(149,6,'2015-10-01',328.00,'2015-10-21 16:39:41','2015-10-21 16:39:41'),(150,1,'2015-11-01',298.97,'2015-11-14 12:51:20','2015-11-14 12:51:20'),(151,2,'2015-11-01',162.68,'2015-11-14 12:51:20','2015-11-14 12:51:20'),(152,3,'2015-11-01',166.95,'2015-11-14 12:51:20','2015-11-14 12:51:20'),(153,4,'2015-11-01',283.90,'2015-11-14 12:51:20','2015-11-14 12:51:20'),(154,5,'2015-11-01',130.32,'2015-11-14 12:51:20','2015-11-14 12:51:20'),(155,6,'2015-11-01',328.00,'2015-11-14 12:51:20','2015-11-14 12:51:20'),(156,7,'2015-06-01',0.00,'2015-11-28 05:04:41','2015-11-28 05:04:41'),(157,7,'2015-07-01',0.00,'2015-11-28 05:04:41','2015-11-28 05:04:41'),(158,7,'2015-08-01',0.00,'2015-11-28 05:04:41','2015-11-28 05:04:41'),(159,7,'2015-09-01',0.00,'2015-11-28 05:04:41','2015-11-28 05:04:41'),(160,7,'2015-10-01',0.00,'2015-11-28 05:04:41','2015-11-28 05:04:41'),(161,7,'2015-11-01',0.00,'2015-11-28 05:04:41','2015-11-28 05:04:41'),(162,1,'2015-12-01',10.00,'2015-12-10 13:22:08','2015-12-10 13:22:25'),(163,2,'2015-12-01',0.00,'2015-12-10 13:28:46','2015-12-10 13:28:46');
/*!40000 ALTER TABLE `budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Automotive, Home & Games','Awesome Silk Bench','2015-09-04 17:29:54','2015-09-04 17:29:54'),(2,'Beauty, Music & Automotive','Ergonomic Paper Bench','2015-09-04 17:29:54','2015-09-04 17:29:54'),(3,'Garden, Health, Books, Industrial & Home','Durable Iron Clock','2015-09-04 17:29:54','2015-09-04 17:29:54'),(4,'Loans','All loans','2015-09-04 17:29:54','2015-09-04 17:29:54'),(5,'Credit Cards','Credit Card Payment','2015-09-04 17:29:54','2015-09-04 17:29:54'),(6,'Savings','all savings','2015-09-26 02:31:05','2015-09-26 02:31:05'),(7,'Rent','Rent','2015-11-28 05:04:41','2015-11-28 05:04:41');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debt_balances`
--

DROP TABLE IF EXISTS `debt_balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debt_balances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `debt_id` int(11) DEFAULT NULL,
  `due_date` date NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `payment_start_date` date DEFAULT NULL,
  `target_balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `by_debt_due_date` (`debt_id`,`due_date`),
  KEY `index_debt_balances_on_debt_id` (`debt_id`),
  KEY `index_debt_balances_on_payment_start_date` (`payment_start_date`),
  CONSTRAINT `fk_rails_018983ce3e` FOREIGN KEY (`debt_id`) REFERENCES `debts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debt_balances`
--

LOCK TABLES `debt_balances` WRITE;
/*!40000 ALTER TABLE `debt_balances` DISABLE KEYS */;
INSERT INTO `debt_balances` VALUES (1,1,'2015-09-15',1000.00,'2015-09-04 18:39:29','2015-12-01 02:42:52','2015-08-16',0.00),(2,2,'2019-01-01',4400.00,'2015-09-04 19:14:36','2015-11-30 12:53:59','2015-04-01',0.00),(3,1,'2015-08-15',500.00,'2015-09-04 19:16:17','2015-12-01 02:43:06','2015-07-16',0.00),(4,1,'2015-10-15',1000.00,'2015-09-04 19:19:29','2015-12-01 02:42:37','2015-09-16',0.00),(5,1,'2015-11-15',500.00,'2015-09-04 19:19:53','2015-10-15 16:30:38','2015-10-16',0.00),(6,1,'2015-01-15',3020.12,'2015-09-04 21:12:17','2015-12-01 02:44:47','2014-12-16',0.00),(7,1,'2015-02-15',2021.96,'2015-09-04 21:12:17','2015-12-01 02:44:27','2015-01-16',0.00),(8,1,'2015-03-15',2156.72,'2015-09-04 21:12:17','2015-12-01 02:44:17','2015-02-16',0.00),(9,1,'2015-04-15',2524.68,'2015-09-04 21:12:17','2015-12-01 02:44:02','2015-03-16',0.00),(10,1,'2015-05-15',2779.96,'2015-09-04 21:12:17','2015-12-01 02:43:50','2015-04-16',0.00),(11,1,'2015-06-15',3447.21,'2015-09-04 21:12:17','2015-12-01 02:43:34','2015-05-16',0.00),(12,1,'2015-07-15',3852.46,'2015-09-04 21:12:17','2015-12-01 02:43:21','2015-06-16',0.00),(13,4,'2018-12-01',14000.00,'2015-10-15 16:58:27','2015-10-15 16:58:27','2014-06-01',0.00),(14,8,'2017-02-01',26350.00,'2015-11-27 21:06:13','2015-11-27 21:11:40','2015-10-01',0.00),(15,1,'2015-12-15',4325.00,'2015-12-06 02:30:15','2015-12-06 02:30:15','2015-11-16',0.00);
/*!40000 ALTER TABLE `debt_balances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debts`
--

DROP TABLE IF EXISTS `debts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sub_category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `is_asset` tinyint(1) DEFAULT '0',
  `pay_from` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Bank Of America',
  `deleted_at` datetime DEFAULT NULL,
  `fix_amount` decimal(10,2) DEFAULT NULL,
  `schedule` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_start_date` date DEFAULT NULL,
  `autopay` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `by_category_name` (`category`,`name`,`deleted_at`),
  KEY `index_debts_on_deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debts`
--

LOCK TABLES `debts` WRITE;
/*!40000 ALTER TABLE `debts` DISABLE KEYS */;
INSERT INTO `debts` VALUES (1,'Credit Cards','Credit Cards','Amex','2015-09-04 17:29:53','2015-09-04 17:29:53',0,'Bank Of America',NULL,NULL,NULL,NULL,0),(2,'Loans','Student Loans','Wolff Academy','2015-09-04 17:29:54','2015-10-15 16:46:09',0,'Chase',NULL,NULL,NULL,NULL,0),(4,'Loans','Car Loans','Vw','2015-10-15 16:46:51','2015-11-27 20:25:00',0,'Bank Of America',NULL,186.19,'Bi-Weekly','2015-09-11',1),(5,'Savings','Savings','Emergency Fundings','2015-11-26 20:33:26','2015-11-26 20:34:44',1,'Bank Of America','2015-11-26 20:34:44',NULL,NULL,NULL,0),(6,'Savings','Savings','Emergency Fundings','2015-11-26 20:51:30','2015-11-26 21:30:01',1,'Bank Of America','2015-11-26 21:30:01',NULL,NULL,NULL,0),(7,'Savings','Savings','Emergency Fundings','2015-11-26 21:38:19','2015-11-26 21:38:19',1,'Bank Of America',NULL,NULL,NULL,NULL,0),(8,'Bill','Bill','Rent','2015-11-27 21:02:29','2015-11-28 05:59:54',0,'Bank Of America',NULL,1550.00,'Monthly',NULL,0),(9,'Loans','Phone','Sams Phone','2015-12-05 18:39:57','2015-12-05 18:39:57',0,'Bank Of America',NULL,NULL,'Bi-Weekly',NULL,0);
/*!40000 ALTER TABLE `debts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `income_distributions`
--

DROP TABLE IF EXISTS `income_distributions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `income_distributions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `distribution_date` date DEFAULT NULL,
  `boa_chk` decimal(8,2) NOT NULL,
  `chase_chk` decimal(8,2) NOT NULL,
  `paid` tinyint(1) DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `chase_focus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `boa_focus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_income_distributions_on_distribution_date` (`distribution_date`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `income_distributions`
--

LOCK TABLES `income_distributions` WRITE;
/*!40000 ALTER TABLE `income_distributions` DISABLE KEYS */;
INSERT INTO `income_distributions` VALUES (4,'2015-10-23',436.19,10.00,0,'2015-10-15 18:11:26','2015-11-02 14:26:48','Chase','Amex'),(5,'2015-11-06',1085.00,80.00,0,'2015-10-15 19:16:31','2015-11-28 03:26:45','Wolff Academy','Amex'),(6,'2015-10-16',1863.88,710.00,0,'2015-10-17 17:32:02','2015-11-19 20:36:40','Wolff Academy','Amex'),(7,'2015-10-30',2103.00,10.00,0,'2015-10-17 17:40:20','2015-11-28 16:13:09','Wolff Academy','Amex'),(8,'2015-11-28',2600.00,1010.00,0,'2015-11-28 16:14:44','2015-11-28 16:15:10','Wolff Academy','Bank Of America'),(9,'2015-12-04',2934.00,2000.00,1,'2015-11-29 16:36:08','2015-12-04 16:29:51','Wolff Academy','Wolff Academy');
/*!40000 ALTER TABLE `income_distributions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `income_sources`
--

DROP TABLE IF EXISTS `income_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `income_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pay_schedule` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pay_day` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` decimal(8,2) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `income_sources`
--

LOCK TABLES `income_sources` WRITE;
/*!40000 ALTER TABLE `income_sources` DISABLE KEYS */;
INSERT INTO `income_sources` VALUES (1,'Job 3','bi-weekly','friday',100.00,'2015-06-05','2015-08-31','2015-12-13 19:43:15','2015-12-14 00:42:21'),(2,'Job 2','semi-monthly','15, last',100.00,'2015-10-01','2015-12-31','2015-12-13 22:10:29','2015-12-14 00:42:02'),(3,'Job 1','weekly','thursday',100.00,'2015-01-01','2015-12-31','2015-12-14 00:41:21','2015-12-14 00:41:38');
/*!40000 ALTER TABLE `income_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_methods`
--

DROP TABLE IF EXISTS `payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_payment_methods_on_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_methods`
--

LOCK TABLES `payment_methods` WRITE;
/*!40000 ALTER TABLE `payment_methods` DISABLE KEYS */;
INSERT INTO `payment_methods` VALUES (1,'Credit','Any of our cc','2015-09-04 17:29:53','2015-09-04 17:29:53'),(2,'Debit','Any of our debit','2015-09-04 17:29:53','2015-09-04 17:29:53'),(3,'Gift','Any gift card','2015-09-04 17:29:53','2015-09-04 17:29:53'),(4,'Cash','Cash','2015-09-04 17:29:53','2015-09-04 17:29:53'),(5,'Other','Any other form of payments','2015-09-04 17:29:53','2015-09-04 17:29:53');
/*!40000 ALTER TABLE `payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('20150705142415'),('20150705142815'),('20150824134412'),('20150826134546'),('20150826205503'),('20150901174002'),('20150901174504'),('20150904153448'),('20150904175601'),('20150907154819'),('20150912200636'),('20150914213216'),('20150919031028'),('20151010193457'),('20151126202850'),('20151126210827'),('20151127193950'),('20151213155844');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spendings`
--

DROP TABLE IF EXISTS `spendings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spendings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `spending_date` date NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `budget_id` int(11) DEFAULT NULL,
  `payment_method_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_spendings_on_category_id` (`category_id`) USING BTREE,
  KEY `index_spendings_on_spending_date` (`spending_date`) USING BTREE,
  KEY `index_spendings_on_budget_id` (`budget_id`),
  KEY `index_spendings_on_payment_method_id` (`payment_method_id`),
  CONSTRAINT `fk_rails_2473d18826` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`),
  CONSTRAINT `fk_rails_4aac1c2679` FOREIGN KEY (`budget_id`) REFERENCES `budgets` (`id`),
  CONSTRAINT `fk_rails_6ec4a5bdad` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spendings`
--

LOCK TABLES `spendings` WRITE;
/*!40000 ALTER TABLE `spendings` DISABLE KEYS */;
INSERT INTO `spendings` VALUES (1,'Wolff Academy',4,'2015-05-08',92.44,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2),(2,'Awesome Granite Pants',1,'2015-05-23',55.79,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,4),(3,'Amex',5,'2015-06-12',92.20,'2015-09-04 17:29:54','2015-09-04 17:29:54',5,2),(4,'Gorgeous Concrete Clock',1,'2015-09-08',32.32,'2015-09-04 17:29:54','2015-09-04 17:29:54',16,2),(5,'Sleek Granite Lamp',2,'2015-05-01',34.70,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,3),(6,'Amex',5,'2015-09-25',22.60,'2015-09-04 17:29:54','2015-09-04 17:29:54',20,2),(7,'Amex',5,'2015-06-23',23.95,'2015-09-04 17:29:54','2015-09-04 17:29:54',5,2),(8,'Practical Granite Coat',1,'2015-09-24',54.61,'2015-09-04 17:29:54','2015-09-04 17:29:54',16,4),(9,'Incredible Aluminum Coat',1,'2015-05-04',24.66,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,1),(10,'Enormous Bronze Shoes',2,'2015-09-03',15.41,'2015-09-04 17:29:54','2015-09-04 17:29:54',17,3),(11,'Amex',5,'2015-06-25',85.88,'2015-09-04 17:29:54','2015-09-04 17:29:54',5,2),(12,'Wolff Academy',4,'2015-06-16',83.51,'2015-09-04 17:29:54','2015-09-04 17:29:54',4,2),(13,'Gorgeous Steel Table',2,'2015-07-14',80.56,'2015-09-04 17:29:54','2015-09-04 17:29:54',7,3),(14,'Synergistic Rubber Coat',3,'2015-07-08',60.65,'2015-09-04 17:29:54','2015-09-04 17:29:54',8,2),(15,'Heavy Duty Plastic Plate',2,'2015-09-19',94.74,'2015-09-04 17:29:54','2015-09-04 17:29:54',17,4),(16,'Incredible Leather Clock',3,'2015-06-25',9.72,'2015-09-04 17:29:54','2015-09-04 17:29:54',3,4),(17,'Awesome Plastic Plate',2,'2015-08-13',56.06,'2015-09-04 17:29:54','2015-09-04 17:29:54',12,2),(18,'Wolff Academy',4,'2015-08-31',74.84,'2015-09-04 17:29:54','2015-09-04 17:29:54',14,2),(19,'Wolff Academy',4,'2015-07-13',32.98,'2015-09-04 17:29:54','2015-09-04 17:29:54',9,2),(20,'Wolff Academy',4,'2015-07-09',56.34,'2015-09-04 17:29:54','2015-09-04 17:29:54',9,2),(21,'Heavy Duty Linen Computer',1,'2015-06-10',78.65,'2015-09-04 17:29:54','2015-09-04 17:29:54',1,4),(22,'Lightweight Cotton Hat',1,'2015-06-16',32.93,'2015-09-04 17:29:54','2015-09-04 17:29:54',1,3),(23,'Durable Granite Bottle',1,'2015-05-07',67.66,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2),(24,'Wolff Academy',4,'2015-06-06',93.84,'2015-09-04 17:29:54','2015-09-04 17:29:54',4,2),(25,'Amex',5,'2015-07-30',66.66,'2015-09-04 17:29:54','2015-09-04 17:29:54',10,2),(26,'Amex',5,'2015-05-30',87.80,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2),(27,'Wolff Academy',4,'2015-05-23',26.18,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2),(28,'Incredible Linen Bag',1,'2015-07-03',88.29,'2015-09-04 17:29:54','2015-09-04 17:29:54',6,5),(29,'Wolff Academy',4,'2015-05-01',21.33,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2),(30,'Wolff Academy',4,'2015-06-21',44.63,'2015-09-04 17:29:54','2015-09-04 17:29:54',4,2),(31,'Rustic Bronze Shirt',1,'2015-05-30',25.50,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,1),(32,'Awesome Iron Plate',3,'2015-08-01',11.99,'2015-09-04 17:29:54','2015-09-04 17:29:54',13,2),(33,'Fantastic Bronze Shirt',3,'2015-05-06',9.44,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,1),(34,'Wolff Academy',4,'2015-08-23',93.38,'2015-09-04 17:29:54','2015-09-04 17:29:54',14,2),(35,'Sleek Leather Lamp',1,'2015-08-01',58.82,'2015-09-04 17:29:54','2015-09-04 17:29:54',11,3),(36,'Heavy Duty Marble Keyboard',1,'2015-06-19',40.90,'2015-09-04 17:29:54','2015-09-04 17:29:54',1,1),(37,'Enormous Granite Plate',3,'2015-09-21',61.38,'2015-09-04 17:29:54','2015-09-04 17:29:54',18,2),(38,'Durable Granite Gloves',3,'2015-05-06',2.53,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,5),(39,'Wolff Academy',4,'2015-07-17',37.22,'2015-09-04 17:29:54','2015-09-04 17:29:54',9,2),(40,'Small Iron Bench',1,'2015-08-23',0.02,'2015-09-04 17:29:54','2015-09-04 17:29:54',11,5),(41,'Wolff Academy',4,'2015-08-16',49.68,'2015-09-04 17:29:54','2015-09-04 17:29:54',14,2),(42,'Mediocre Concrete Shoes',2,'2015-09-09',65.38,'2015-09-04 17:29:54','2015-09-04 17:29:54',17,3),(43,'Wolff Academy',4,'2015-08-28',60.20,'2015-09-04 17:29:54','2015-09-04 17:29:54',14,2),(44,'Lightweight Cotton Coat',3,'2015-06-05',81.35,'2015-09-04 17:29:54','2015-09-04 17:29:54',3,1),(45,'Small Bronze Computer',1,'2015-08-26',99.14,'2015-09-04 17:29:54','2015-09-04 17:29:54',11,3),(46,'Mediocre Leather Computer',1,'2015-08-09',25.49,'2015-09-04 17:29:54','2015-09-04 17:29:54',11,1),(47,'Fantastic Linen Table',3,'2015-07-15',82.50,'2015-09-04 17:29:54','2015-09-04 17:29:54',8,2),(48,'Wolff Academy',4,'2015-06-21',16.55,'2015-09-04 17:29:54','2015-09-04 17:29:54',4,2),(49,'Sleek Iron Bench',1,'2015-07-23',42.06,'2015-09-04 17:29:54','2015-09-04 17:29:54',6,1),(50,'Wolff Academy',4,'2015-08-16',27.10,'2015-09-04 17:29:54','2015-09-04 17:29:54',14,2),(51,'Wolff Academy',4,'2015-05-09',76.31,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2),(52,'Fantastic Leather Watch',1,'2015-06-10',83.02,'2015-09-04 17:29:54','2015-09-04 17:29:54',1,1),(53,'Small Wooden Chair',1,'2015-05-28',59.81,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,5),(54,'Amex',5,'2015-09-21',20.73,'2015-09-04 17:29:54','2015-09-04 17:29:54',20,2),(55,'Synergistic Steel Car',2,'2015-07-16',64.06,'2015-09-04 17:29:54','2015-09-04 17:29:54',7,2),(56,'Aerodynamic Granite Bottle',2,'2015-05-08',20.75,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,3),(57,'Fantastic Wool Coat',1,'2015-06-27',68.48,'2015-09-04 17:29:54','2015-09-04 17:29:54',1,5),(58,'Awesome Copper Plate',2,'2015-07-06',95.81,'2015-09-04 17:29:54','2015-09-04 17:29:54',7,2),(59,'Wolff Academy',4,'2015-06-21',8.17,'2015-09-04 17:29:54','2015-09-04 17:29:54',4,2),(60,'Wolff Academy',4,'2015-09-22',97.93,'2015-09-04 17:29:54','2015-09-04 17:29:54',19,2),(61,'Heavy Duty Linen Wallet',3,'2015-06-30',90.99,'2015-09-04 17:29:54','2015-09-04 17:29:54',3,4),(62,'Amex',5,'2015-08-24',52.32,'2015-09-04 17:29:54','2015-09-04 17:29:54',15,2),(63,'Wolff Academy',4,'2015-05-20',55.66,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2),(64,'Practical Aluminum Bench',3,'2015-06-23',64.40,'2015-09-04 17:29:54','2015-09-04 17:29:54',3,1),(65,'Fantastic Steel Pants',3,'2015-07-27',73.46,'2015-09-04 17:29:54','2015-09-04 17:29:54',8,2),(66,'Wolff Academy',4,'2015-09-17',33.99,'2015-09-04 17:29:54','2015-09-04 17:29:54',19,2),(67,'Durable Bronze Hat',1,'2015-05-21',20.78,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,5),(68,'Awesome Steel Keyboard',3,'2015-08-09',43.78,'2015-09-04 17:29:54','2015-09-04 17:29:54',13,5),(69,'Awesome Marble Bench',1,'2015-05-11',98.68,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,5),(70,'Wolff Academy',4,'2015-06-09',26.96,'2015-09-04 17:29:54','2015-09-04 17:29:54',4,2),(71,'Sleek Paper Knife',1,'2015-06-29',47.94,'2015-09-04 17:29:54','2015-09-04 17:29:54',1,1),(72,'Heavy Duty Linen Chair',3,'2015-05-24',9.36,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,4),(73,'Amex',5,'2015-06-09',19.99,'2015-09-04 17:29:54','2015-09-04 17:29:54',5,2),(74,'Lightweight Plastic Coat',1,'2015-09-21',49.44,'2015-09-04 17:29:54','2015-09-04 17:29:54',16,4),(75,'Wolff Academy',4,'2015-09-23',76.71,'2015-09-04 17:29:54','2015-09-04 17:29:54',19,2),(76,'Wolff Academy',4,'2015-07-19',54.20,'2015-09-04 17:29:54','2015-09-04 17:29:54',9,2),(77,'Synergistic Leather Knife',1,'2015-06-07',20.50,'2015-09-04 17:29:54','2015-09-04 17:29:54',1,4),(78,'Heavy Duty Cotton Shoes',2,'2015-06-07',85.32,'2015-09-04 17:29:54','2015-09-04 17:29:54',2,3),(79,'Rustic Granite Bottle',2,'2015-07-23',7.58,'2015-09-04 17:29:54','2015-09-04 17:29:54',7,1),(80,'Mediocre Aluminum Coat',2,'2015-07-15',6.56,'2015-09-04 17:29:54','2015-09-04 17:29:54',7,2),(81,'Wolff Academy',4,'2015-08-08',17.91,'2015-09-04 17:29:54','2015-09-04 17:29:54',14,2),(82,'Ergonomic Aluminum Wallet',1,'2015-07-12',65.76,'2015-09-04 17:29:54','2015-09-04 17:29:54',6,1),(83,'Wolff Academy',4,'2015-07-04',60.97,'2015-09-04 17:29:54','2015-09-04 17:29:54',9,2),(84,'Amex',5,'2015-08-08',32.67,'2015-09-04 17:29:54','2015-09-04 17:29:54',15,2),(85,'Incredible Marble Plate',2,'2015-09-26',37.77,'2015-09-04 17:29:54','2015-09-04 17:29:54',17,4),(86,'Incredible Steel Knife',2,'2015-08-28',27.24,'2015-09-04 17:29:54','2015-09-04 17:29:54',12,2),(87,'Small Paper Table',1,'2015-05-17',95.56,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,1),(88,'Mediocre Copper Table',3,'2015-08-25',62.37,'2015-09-04 17:29:54','2015-09-04 17:29:54',13,2),(89,'Rustic Marble Lamp',1,'2015-06-30',97.99,'2015-09-04 17:29:54','2015-09-04 17:29:54',1,3),(90,'Enormous Plastic Keyboard',2,'2015-05-26',65.51,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,5),(91,'Heavy Duty Paper Pants',3,'2015-08-04',23.49,'2015-09-04 17:29:54','2015-09-04 17:29:54',13,3),(92,'Small Wooden Keyboard',3,'2015-06-23',9.81,'2015-09-04 17:29:54','2015-09-04 17:29:54',3,4),(93,'Heavy Duty Bronze Clock',3,'2015-06-05',58.44,'2015-09-04 17:29:54','2015-09-04 17:29:54',3,2),(94,'Amex',5,'2015-08-27',19.02,'2015-09-04 17:29:54','2015-09-04 17:29:54',15,2),(95,'Amex',5,'2015-08-01',53.94,'2015-09-04 17:29:54','2015-09-04 17:29:54',15,2),(96,'Wolff Academy',4,'2015-09-21',21.87,'2015-09-04 17:29:54','2015-09-04 17:29:54',19,2),(97,'Rustic Paper Coat',3,'2015-08-06',79.07,'2015-09-04 17:29:55','2015-09-04 17:29:55',13,3),(98,'Wolff Academy',4,'2015-09-23',78.62,'2015-09-04 17:29:55','2015-09-04 17:29:55',19,2),(99,'Heavy Duty Concrete Car',1,'2015-05-04',60.03,'2015-09-04 17:29:55','2015-09-04 17:29:55',NULL,2),(100,'Amex',5,'2015-06-06',73.83,'2015-09-04 17:29:55','2015-09-04 17:29:55',5,2),(101,'Shea Moisture',2,'2015-09-04',55.95,'2015-09-05 01:40:46','2015-09-05 01:40:46',17,1),(102,'Emergency',6,'2015-09-25',328.00,'2015-09-26 02:51:58','2015-09-26 02:51:58',24,2),(103,'Amex',5,'2015-11-04',450.00,'2015-11-26 01:56:49','2015-11-26 01:57:28',154,2),(113,'Avalon',7,'2015-11-01',1526.00,'2015-11-28 05:05:13','2015-11-28 05:50:55',161,2),(122,'Should Get Warning',1,'2015-11-30',300.00,'2015-12-01 00:05:02','2015-12-01 00:05:02',150,1),(123,'Wolff Academy',4,'2015-12-04',2980.48,'2015-12-04 16:29:51','2015-12-04 16:29:51',NULL,2),(124,'Vw',4,'2015-12-04',186.19,'2015-12-04 16:29:51','2015-12-04 16:29:51',NULL,2),(125,'Should Add New Budget',2,'2015-12-16',23.00,'2015-12-10 13:28:46','2015-12-10 13:28:46',163,1);
/*!40000 ALTER TABLE `spendings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_digest` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_digest` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activation_digest` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activated` tinyint(1) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_users_on_email` (`email`),
  UNIQUE KEY `index_users_on_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Emmanuel','Thomas','titbabthomas@gmail.com','thome127','$2a$10$.YtrSjOdV7AyO7xpSWMcVeQ2yBUuXFC22pUyBJS4Ai3K0oxybhreq',NULL,'$2a$10$YVMU5XMeDQltGirRMCMSTu.vROM7.ZTJ8WarxjK6nc9jZRAEG9AYq',NULL,'2015-08-25 12:28:11','2015-08-25 12:28:11');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-12-13 20:12:59
